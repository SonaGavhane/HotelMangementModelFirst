﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModelbuild
{
    class Program
    {
        static void Main(string[] args)
        {
            Room r = new Room();
            Building b = new Building();
            r.name = "Nivas";
            r.description = "afstfsdtfugjrhh";
            r.capacity = 4;
            r.enable = 1;
            r.note = "dhdfiuur";
            r.smart = 1;
            r.idBuilding = 1;
            
            string sqlInsert= String.Format("insert into Rooms(Name,description,capacity,enable,note,smart,building id) values('{0}','{1}',{2},{3},'{4}',{5},{6})", r.name, r.description,r.capacity,r.enable,r.note,r.smart,r.idBuilding);
            Console.WriteLine("QUERY \t" + sqlInsert);
            buildModel1Container db = new buildModel1Container();
            int res = db.Database.ExecuteSqlCommand(sqlInsert);

            if (res == 1)
             Console.WriteLine("Query inserted");
            else
                Console.WriteLine("ERROR in inserting data");
        }
    }
}
