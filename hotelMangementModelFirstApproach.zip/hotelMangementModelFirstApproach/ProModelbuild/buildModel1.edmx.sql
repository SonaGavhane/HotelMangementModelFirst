
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 08/17/2021 23:49:05
-- Generated from EDMX file: C:\Users\admin\source\repos\ProModelbuild\ProModelbuild\buildModel1.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [ProjectBuildModel];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Rooms'
CREATE TABLE [dbo].[Rooms] (
    [idRoom] int IDENTITY(1,1) NOT NULL,
    [name] nvarchar(max)  NOT NULL,
    [description] nvarchar(max)  NOT NULL,
    [capacity] int  NOT NULL,
    [enable] int  NOT NULL,
    [note] nvarchar(max)  NOT NULL,
    [smart] int  NOT NULL,
    [idBuilding] int  NOT NULL,
    [Building_idBuilding] int  NOT NULL
);
GO

-- Creating table 'Buildings'
CREATE TABLE [dbo].[Buildings] (
    [idBuilding] int IDENTITY(1,1) NOT NULL,
    [floor] int  NOT NULL,
    [latitude] int  NOT NULL,
    [longitude] int  NOT NULL,
    [idAddress] int  NOT NULL,
    [Address_idAddress] int  NOT NULL
);
GO

-- Creating table 'Addresses'
CREATE TABLE [dbo].[Addresses] (
    [idAddress] int IDENTITY(1,1) NOT NULL,
    [address1] nvarchar(max)  NOT NULL,
    [address2] nvarchar(max)  NOT NULL,
    [address3] nvarchar(max)  NOT NULL,
    [postalCode] nvarchar(max)  NOT NULL,
    [idCity] int  NOT NULL,
    [City_idCity] int  NOT NULL
);
GO

-- Creating table 'Cities'
CREATE TABLE [dbo].[Cities] (
    [idCity] int IDENTITY(1,1) NOT NULL,
    [cityName] nvarchar(max)  NOT NULL,
    [idCountry] int  NOT NULL,
    [Country_idCountry] int  NOT NULL
);
GO

-- Creating table 'Countries'
CREATE TABLE [dbo].[Countries] (
    [idCountry] int IDENTITY(1,1) NOT NULL,
    [countryName] nvarchar(max)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [idRoom] in table 'Rooms'
ALTER TABLE [dbo].[Rooms]
ADD CONSTRAINT [PK_Rooms]
    PRIMARY KEY CLUSTERED ([idRoom] ASC);
GO

-- Creating primary key on [idBuilding] in table 'Buildings'
ALTER TABLE [dbo].[Buildings]
ADD CONSTRAINT [PK_Buildings]
    PRIMARY KEY CLUSTERED ([idBuilding] ASC);
GO

-- Creating primary key on [idAddress] in table 'Addresses'
ALTER TABLE [dbo].[Addresses]
ADD CONSTRAINT [PK_Addresses]
    PRIMARY KEY CLUSTERED ([idAddress] ASC);
GO

-- Creating primary key on [idCity] in table 'Cities'
ALTER TABLE [dbo].[Cities]
ADD CONSTRAINT [PK_Cities]
    PRIMARY KEY CLUSTERED ([idCity] ASC);
GO

-- Creating primary key on [idCountry] in table 'Countries'
ALTER TABLE [dbo].[Countries]
ADD CONSTRAINT [PK_Countries]
    PRIMARY KEY CLUSTERED ([idCountry] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [Building_idBuilding] in table 'Rooms'
ALTER TABLE [dbo].[Rooms]
ADD CONSTRAINT [FK_RoomBuilding]
    FOREIGN KEY ([Building_idBuilding])
    REFERENCES [dbo].[Buildings]
        ([idBuilding])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_RoomBuilding'
CREATE INDEX [IX_FK_RoomBuilding]
ON [dbo].[Rooms]
    ([Building_idBuilding]);
GO

-- Creating foreign key on [Address_idAddress] in table 'Buildings'
ALTER TABLE [dbo].[Buildings]
ADD CONSTRAINT [FK_BuildingAddress]
    FOREIGN KEY ([Address_idAddress])
    REFERENCES [dbo].[Addresses]
        ([idAddress])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_BuildingAddress'
CREATE INDEX [IX_FK_BuildingAddress]
ON [dbo].[Buildings]
    ([Address_idAddress]);
GO

-- Creating foreign key on [City_idCity] in table 'Addresses'
ALTER TABLE [dbo].[Addresses]
ADD CONSTRAINT [FK_AddressCity]
    FOREIGN KEY ([City_idCity])
    REFERENCES [dbo].[Cities]
        ([idCity])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AddressCity'
CREATE INDEX [IX_FK_AddressCity]
ON [dbo].[Addresses]
    ([City_idCity]);
GO

-- Creating foreign key on [Country_idCountry] in table 'Cities'
ALTER TABLE [dbo].[Cities]
ADD CONSTRAINT [FK_CityCountry]
    FOREIGN KEY ([Country_idCountry])
    REFERENCES [dbo].[Countries]
        ([idCountry])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CityCountry'
CREATE INDEX [IX_FK_CityCountry]
ON [dbo].[Cities]
    ([Country_idCountry]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------